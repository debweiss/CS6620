.. title: Nikola: it generates static
.. slug: about-nikola
.. date: 2012-03-30 23:00:00 UTC-03:00
.. tags: 
.. link: 
.. description: 

Hope you enjoy this software!

* Home page at https://getnikola.com/
* Author's blog (and reason why Nikola exists): https://ralsina.me/
